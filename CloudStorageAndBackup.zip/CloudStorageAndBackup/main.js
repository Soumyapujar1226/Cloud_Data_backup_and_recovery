// Initialize Firebase
import { initializeApp } from "https://www.gstatic.com/firebasejs/9.6.9/firebase-app.js";
import {
  getStorage,
  ref,
  uploadBytes,
  listAll,
  getDownloadURL,
} from "https://www.gstatic.com/firebasejs/9.6.9/firebase-storage.js";

const firebaseConfig = {
  apiKey: "AIzaSyApC01Hm-PFtknDO4NfJGVld8AmZT1RDEw",
  authDomain: "quickreach-494a3.firebaseapp.com",
  databaseURL: "https://quickreach-494a3-default-rtdb.firebaseio.com",
  projectId: "quickreach-494a3",
  storageBucket: "quickreach-494a3.appspot.com",
  messagingSenderId: "75132187221",
  appId: "1:75132187221:web:0ddd3f0e50e59b6d281adc",
  measurementId: "G-9LE6FKFLCM",
};

// Initialize Firebase app and storage
const app = initializeApp(firebaseConfig);
const storage = getStorage(app);

// Wait until DOM content is fully loaded
document.addEventListener("DOMContentLoaded", () => {
  // Backup files
  document.getElementById("backupBtn").addEventListener("click", async () => {
    const fileInput = document.querySelector("#fileInput");
    if (!fileInput || fileInput.files.length === 0) {
      alert("Please select files to backup!");
      return;
    }
    const files = fileInput.files;
    for (const file of files) {
      const storageRef = ref(storage, `backup/${file.name}`);
      await uploadBytes(storageRef, file);
      alert(`Uploaded ${file.name}`);
    }
  });

  // Recover files
  document.getElementById("recoverBtn").addEventListener("click", async () => {
    const fileName = document.getElementById("recoverFileName").value;
    if (!fileName) {
      alert("Please enter a file name to recover.");
      return;
    }
    try {
      const storageRef = ref(storage, `backup/${fileName}`);
      const url = await getDownloadURL(storageRef);
      window.open(url, "_blank");
      alert(`File ${fileName} has been recovered successfully!`);
    } catch (error) {
      alert(`Error recovering file: ${error.message}`);
    }
  });

  // List files in the cloud
  document.getElementById("listBtn").addEventListener("click", async () => {
    try {
      const storageRef = ref(storage, "backup");
      const result = await listAll(storageRef);
      const fileList = document.getElementById("filesList");
      fileList.innerHTML = "";
      for (const itemRef of result.items) {
        const li = document.createElement("li");
        li.textContent = itemRef.name;
        fileList.appendChild(li);
      }
    } catch (error) {
      alert(`Error listing cloud files: ${error.message}`);
    }
  });

  // List local files from the local_backup folder (Mock Display)
  document.getElementById("localListBtn").addEventListener("click", async () => {
    try {
      const localFilesList = document.getElementById("localFilesList");
      const response = await fetch("http://localhost:5000/local-files"); // Mock server endpoint
      const files = await response.json();
      localFilesList.innerHTML = "";
      files.forEach((file) => {
        const li = document.createElement("li");
        li.textContent = file;
        localFilesList.appendChild(li);
      });
    } catch (error) {
      alert(`Error fetching local files: ${error.message}`);
    }
  });
});
