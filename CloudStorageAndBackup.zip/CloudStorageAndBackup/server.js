const express = require("express");
const multer = require("multer");
const fs = require("fs");
const path = require("path");
const cors = require("cors");
const bucket = require("./firebase"); // Ensure this file is correctly set up for Firebase

const app = express();
const PORT = 5000;

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname))); // Serve files from the main directory

// Multer setup for file uploads
const upload = multer({ dest: path.join(__dirname, "uploads/") });

app.get("/local-files", (req, res) => {
  const localBackupPath = path.join(__dirname, "local_backup");
  if (!fs.existsSync(localBackupPath)) {
    return res.status(404).send("local_backup folder not found!");
  }

  const files = fs.readdirSync(localBackupPath);
  res.json(files);
});

// Recover files from Firebase Storage
app.get("/recover", async (req, res) => {
  try {
    const fileName = req.query.file; // Optional file name parameter
    const downloadPath = path.join(__dirname, "downloads");

    // Ensure the downloads folder exists
    if (!fs.existsSync(downloadPath)) {
      fs.mkdirSync(downloadPath);
    }

    if (fileName) {
      // Recover a specific file
      const file = bucket.file(`backups/${fileName}`);
      const destination = path.join(downloadPath, fileName);
      await file.download({ destination });
      console.log(`Downloaded: ${fileName}`);
      return res.send(`File ${fileName} recovered successfully!`);
    } else {
      // Recover all files
      const [files] = await bucket.getFiles({ prefix: "backups/" });

      if (files.length === 0) {
        return res.status(404).send("No files found in the cloud backups!");
      }

      for (const file of files) {
        const destination = path.join(downloadPath, path.basename(file.name));
        await file.download({ destination });
        console.log(`Downloaded: ${file.name}`);
      }

      res.send("All files recovered successfully!");
    }
  } catch (error) {
    console.error("Error during recovery:", error.message);
    res.status(500).send("An error occurred during recovery.");
  }
});

// Upload files using Multer
app.post("/upload", upload.single("file"), async (req, res) => {
  try {
    const file = req.file;

    if (!file) {
      return res.status(400).send("No file uploaded!");
    }

    const storagePath = `uploads/${file.originalname}`;
    await bucket.upload(file.path, { destination: storagePath });
    console.log(`Uploaded: ${file.originalname}`);
    res.send(`File ${file.originalname} uploaded successfully!`);
  } catch (error) {
    console.error("Error during file upload:", error.message);
    res.status(500).send("An error occurred during file upload.");
  }
});

// Start the server
app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});
